/**
 * this is enum class color which has white and black two colors for chess pieces.
 * @author hyojinkwak
 *
 */
public enum Color {
  BLACK, WHITE

}
